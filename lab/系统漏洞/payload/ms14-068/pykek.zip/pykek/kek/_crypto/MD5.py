import hashlib

def new(*args):
    return hashlib.md5(*args)
