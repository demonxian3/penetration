<!DOCTYPE html>
<html>
<head>
    <title>登录成功</title>
</head>
<body>
<script>alert('登录成功')</script>
</body>
</html>