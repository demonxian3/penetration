<?php
  include "b.png";
?>
