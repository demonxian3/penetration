<html>

<head>
<title>Login Page</title>

<meta http-equiv="content-Type" content="text/html;charset=utf-8"/>
</head>

<body>
<h1>User Login</h1>

<form action="checklogin.php" method="post">
Username:<input type="text" name="usernm"/></br>
Password:<input type="password" name="passwd"/></br>
<input type="submit" value="Submit"/>&nbsp&nbsp<input type="reset" value="Reset"/>
</form>

</body>

</html>

