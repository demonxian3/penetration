<?php

  session_start();
  mysql_connect('localhost:3306','root','26678742a');
  mysql_set_charset('utf8');
  mysql_select_db('race');

  $usernm = $_POST['usernm'];
  $passwd =md5($_POST['passwd']);


  //$sql = 'select usernm,passwd from users where usernm = \"'.$usernm.'\" and passwd = \"'.$passwd.'\"';
  $sql = "SELECT usernm,passwd FROM users WHERE usernm = '$usernm' AND passwd = '$passwd'";
  //$sql = "SELECT usernm,passwd FROM users WHERE usernm = '$_POST[usernm]' AND passwd = '$_POST[passwd]'";

echo $sql;

$res = mysql_query($sql);

if($row = mysql_fetch_row($res)){
   echo "<script>alert('login successfully')</script>";
}else{
   echo "login failed";
}
?>
