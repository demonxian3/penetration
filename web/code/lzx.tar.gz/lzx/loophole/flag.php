<?php

$flag = "Your_Successfully_Get_This_Flag_Congratulation!!!";

?>
