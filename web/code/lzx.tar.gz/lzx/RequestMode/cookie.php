<?php
  echo $_COOKIE['c'];
  print_r($_COOKIE);
?>
