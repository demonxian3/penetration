<?php
  echo $_POST['p'] ."<br>";
  var_dump($_POST['p']);
?>
