<?php
  echo $_GET['g'] ."<br>";
  var_dump($_GET['g']);
?>
