<?php
   session_start();
   include "mysql.php";

   $content = $_POST["content"];
   echo $content;

   $date = date("Y/m/d H:i:s");
   $user = $_SESSION["username"];

   $sql = "insert into messages value(NULL,'$content','$user','$date')";
   $res = mysql_query($sql);

   mysql_error("insert query have an error!");
    
   if($res)
     echo "<script>alert('insert successfully')</script>";
   else
     echo "<script>alert('insert failed')</script>";
     
     echo "<script>history.go(-1)</script>";
?>
