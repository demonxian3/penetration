<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="css/layout.css" />
		<!--<link rel="stylesheet" href="css/layout2.css" 登录界面不允许切换风格/>-->
		<link rel="stylesheet" href="css/message.css" />
		<link rel="stylesheet" href="css/form.css" />
		<link rel="stylesheet" href="css/login.css" />
	</head>

	<body>
		<!-- head -->
		<div class="head" id="head" style="cursor:pointer" onclick="tip();">
			<div class="logo" id="logo"></div>
			<div class="headtext" id="headtext">
				登录界面
			</div>
			<div class="login">
			<!--	<a class="regNew" href="register.php">注册</a>-->
			</div>
		</div>


		<!-- content -->
		<div class="content" >
			<div class="login_back" style="background:#282C37">
				<div class="login_main" style="background:#545454;">
					<div class="login_title">
						用户登录
						<form action="checklog.php" method="post">
							<input type="text" id="username" name="username" required="required"/>
							<span id="userS" style="color:#c00000; font-size: 17px;font-family: '微软雅黑';position: absolute;margin-top: 30px; display: none;">&nbsp;不能为空</span>
							<br />
							<input type="password" id="password" name="password" required="required"/>
							<span id="passS" style="color:#c00000; font-size: 17px;font-family: '微软雅黑';position: absolute;margin-top: 30px; display: none;">&nbsp;不能为空</span>
							<br />
							<input type="submit" id="login" value="登录"/>
						</form>
					</div>					
				</div>
			</div>
		</div>


		<!-- foot -->
		<div class="foot" id="foot">
			<div class="foottext">
				©Copyright 2017-2018 Demon All Rights Reserved.
			</div>
		</div>

		<script type="text/javascript" src="js/tip.js" ></script>
		<script type="text/javascript" src="js/login.js" ></script>
 		
	</body>

</html>
