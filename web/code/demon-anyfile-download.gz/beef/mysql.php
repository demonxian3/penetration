<?php
   include "config/config.php";
   mysql_connect("$mysql_ipaddr:$mysql_port","$mysql_user","$mysql_passwd") or die("Cannot connect mysql");
   mysql_set_charset("$mysql_charset");
   mysql_select_db("$mysql_database");
?>

