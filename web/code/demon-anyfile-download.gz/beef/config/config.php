<?php
   $mysql_port = "3306";
   $mysql_charset = "utf8";
   $mysql_database = "beef";
   $mysql_ipaddr = "192.168.10.100";
   $mysql_user = "download_webuser";
   $mysql_passwd = "mysqlpasswd";
?>

