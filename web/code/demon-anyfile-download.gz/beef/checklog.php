<?php
   session_start();
   include "mysql.php";

   $username = input_filter($_POST['username']);
   $password = input_filter($_POST['password']);

   $sql_reject1 = preg_match("/^[0-9a-zA-Z]+$/",$username);
   $sql_reject2 = preg_match("/^[0-9a-zA-Z]+$/",$password);

    if(!$sql_reject1 || !$sql_reject2){
      echo "<script>alert('请不要恶意注入')</script>";
      echo "<script>window.history.go(-1);</script>";
      exit;
   }

   $password = md5($password);

   $sql = "select * from users where username='{$username}' and password='{$password}'";
  

   $res = mysql_query($sql);
   $row = mysql_fetch_assoc($res);

if($row){
   $_SESSION[id]=$row[id];
   $_SESSION[username]=$username;
   $_SESSION[isadmin]= $row[isadmin];
   $url = "index.php";
}
else{
   $url = "login.php";
   echo "<script>alert('账号或密码错误请重新登录')</script>";
}

   echo "<script>window.location='$url'</script>";


function input_filter($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}


