function tip(){
  window.location="http://192.168.10.100";
}

function log(){
  window.location="http://192.168.10.100/login.php";
}

function del(n){
  var url = "http://192.168.10.100/delmsg.php";
  var para = {del:n};
  post(url,para);
}

//post
function post(url, para){
  var temp;
  temp = document.createElement("form");
  temp.action = url;
  temp.method = "post";
  temp.style.display = "none";
  for (var x in para) {
    var opt;
    opt = document.createElement("textarea");
    opt.name = x;
    opt.value = para[x];
    temp.appendChild(opt);
  }
  document.body.appendChild(temp);
  temp.submit();
  return temp;
}
