
<?php
   session_start();
   include "mysql.php";

   echo $_SESSION[isadmin];
   
   if($_SEESION[isadmin]!=1){
     echo "<script>history.go(-1)</script>";
   }

   if($_POST["del"]){
     $sql = "delete from messages where id = $_POST[del]";
     $res = mysql_query($sql); 
     mysql_error("delete query have an error!");
   
   if($res)
     echo "<script>alert('delete successfully')</script>";
   else
     echo "<script>alert('delete failed')</script>";
   }

  
?>
