<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="css/layout.css" />
		<link rel="stylesheet" href="css/layout2.css" />
		<link rel="stylesheet" href="css/button.css" />
		<link rel="stylesheet" href="css/headtext.css" />
		<link rel="stylesheet" href="css/register.css" />
		<link rel="stylesheet" href="css/form.css" />
		<script src="js/jquery.js"></script>
	</head>

	<body>
		<!-- head -->
		<div class="head" id="head">
			<div class="logo" id="logo" onclick="history.go(-1)">

			</div>
			<div class="headtext" id="headtext">
				用户注册界面
			</div>
			<div class="login">
				<a class="loginNew" href="login.php">登陆</a>
			</div>
		</div>


		<!-- content -->
		<div class="content">
			<div class="register">
				<a name="kc"></a>
				
			    <form action="" method="post" class="whiteform">
			    <h1>用户注册<span>使用本网页必须遵守本网页的注册协议，请在下面填写你的个人信息</span></h1>
			
			    <label>
				<span>用户名</span>
			    	<input id="name" type="text" name="username"  class="auth"/>
					<span class='error'>用户名长度至少6位!</span>
			    </label>
			
			    <label>
				<span>密码</span>
			    	<input id="pass" type="password" name="password" class="auth" />
					<span class='error'>密码长度至少8位!</span>
			    	
			    </label>
			    
			     <label>
				<span>密码确认</span>
			    	<input id="repass" type="password" name="repassword"  class="auth"/>
					<span class='error'>两次密码不一致!</span>
			    </label>
			    
			    <label>
			    <span>邮箱</span>
			    	<input id="email" type="email" name="email"  class="auth"/>
					<span class='error'>邮箱格式不正确!</span>
			    </label>
			    
			    <label>
				<span>手机号</span>
			    	<input id="email" type="phone" name="phone" class="auth" />
					<span class='error'>手机号码不正确!</span>
			    </label>
			
			
				<div  class="tijiao">
				<label>
			    	<input type="submit" class="button" value="注册"  />
			    </label>
			    
			    <div class="formtext" style="color: #CBB8C2;">
			    	<input type="checkbox" checked="checked" />
			    	用户勾选即代表同意<a href="userprotocol.html">《用户注册协议》</a>
			    </div>
				<label>
			    </label>
			    </div>
			    </form>
			</div>
		</div>


		<!-- foot -->
		<div class="foot" id="foot">
			<div class="foottext">
				©Copyright 2017-2018 Demon All Rights Reserved.
			</div>
		</div>

		<script type="text/javascript" src="js/change2.js"></script>
		<script type="text/javascript" src="js/validation.js" ></script>

	</body>

</html>
