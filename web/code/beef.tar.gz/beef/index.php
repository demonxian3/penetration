<?php
  session_start();
  if(!$_SESSION[id]){echo "<script>location='login.php'</script>";exit;}
  include "mysql.php";
  $sql = "select * from messages order by id desc limit 5 ";
  $res = mysql_query($sql);
  
?>


<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title></title>
		<link rel="stylesheet" href="css/layout.css" />
		<link rel="stylesheet" href="css/layout2.css" />
		<link rel="stylesheet" href="css/button.css" />
		<link rel="stylesheet" href="css/message.css" />
		<link rel="stylesheet" href="css/form.css" />

	</head>

	<body>
		<!-- head -->
		<div class="head" id="head" style="cursor:pointer" ondblclick="log()" >
			<div class="logo" id="logo"></div>
			<div class="headtext" id="headtext">
				XSS漏洞
			</div>
		</div>


		<!-- content -->
		<div class="content" style="background:#c3c3c3">
			<div class="mokuai display">
				<div class="mokuai_t">留言展示</div>
				<div class="mokuai_c">
					<div class="mokuai_text ">
						<h4>用户留言区块：仅显示最新的5条</h4>

						<?php 

						while($row = mysql_fetch_assoc($res)){

	                                            echo '    <div class="message" id="m1">
        	                                                <div class="mtitle">#'.$row["date"].' <span>'.$row["username"].'</span>&nbsp;说：</div>
                	                                        <div class="mdocker">
                        	                                   <div class="headimg">
                                	                              <img src="pic/headimg1.jpg" />
                                        	                    </div>
                                                	            <div class="mcontent">
							              '.$row["content"].';
                                                                      <br />
                                                               	    </div>';
						   if($_SESSION[isadmin])echo "<div id='$row[id]' class='deleteBtn' onclick='del(this.id)' ><input type='button' value='delete'></div>";
								 
                                                    echo    	 '</div></div>';

						}

						?>
						<!-- sample
						<div class="message" id="m1">
							<div class="mtitle">#2017-6-26 19:15 <span>李子贤</span>&nbsp;说：</div>
							<div class="mdocker">
								<div class="headimg">
									<img src="pic/headimg1.jpg" />
								</div>
								<div class="mcontent">
								</div>
							</div>
						</div>
						-->

					</div>
				</div>
			</div>

			<a name="pub"></a>

			<div class="mokuai publish">
				<div class="mokuai_t">发表留言</div>
				<div class="mokuai_c">
					<div class="mokuai_text ">
						<div class="form">
							<form action="addmsg.php" method="post" class="blueform" id="messageform">
 								<!--
								<label>
									<span>你的名字：</span>
									<input id="name" type="text" name="name" placeholder="姓名" />
								</label>
								-->
								
								
								<label>
									<span>填写留言：</span>
									<textarea id="message" name="content" placeholder="填写你的留言"></textarea>
									</label>
									
								<label>
									<span>&nbsp;</span>
									<input type="submit" class="button" value="发表" id="pubbutton" />
								</label>
							</form>
						</div>
					</div>
				</div>
			</div>

		</div>

		<!-- foot -->
		<div class="foot" id="foot">
			<div class="foottext">
				©Copyright 2017-2018 Demon All Rights Reserved.
			</div>
		</div>

		<script type="text/javascript" src="js/tip.js"></script>

	</body>

</html>
