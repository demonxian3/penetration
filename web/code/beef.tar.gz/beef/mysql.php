<?php
   mysql_connect("localhost:3306","root","123456");
   mysql_set_charset("utf8");
   mysql_select_db("beef");
?>

